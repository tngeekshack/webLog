import Vue from 'vue'
import App from './App'
// UIkitの呼び出し
import UIkit from 'uikit'
import Icons from 'uikit/dist/js/uikit-icons'
import 'uikit/dist/css/uikit.css'
import 'uikit/dist/css/uikit.min.css'
UIkit.use(Icons)

Vue.config.productionTip = false

new Vue({
    el: '#wrapper',
    render: h => h(App)
})