<template>
    <footer>
		(c) GeeksHack.Info
	</footer>
</template>

<style scoped lang="less">
@import "less/footer.less";
</style>