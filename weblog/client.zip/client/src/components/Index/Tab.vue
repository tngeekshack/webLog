<template>
<div class="uk-margin-medium-top">
    <ul class="uk-flex-left" uk-tab="media: 640@s">
        <li class="uk-active"><a href="#">Center</a></li>
        <li><a href="#">Item</a></li>
        <li><a href="#">Item</a></li>
    </ul>
</div>
</template>

