<template>
    <div class="header"><h1>Geeks Hack</h1></div>
</template>

<style scoped lang="less">
@import "less/header.less";
</style>