<template>
<div id= "wrapper">
   <Header/>
   <Tab/>
   <Footer/>
 </div>
</template>

<script>

import Header from "./components/Index/Header"
import Tab from "./components/Index/Tab"
import Footer from "./components/Index/Footer"

export default {
 wrapperObject: 'wrapper',
 components: {
   Header,
   Tab,
   Footer
 }
}
</script>

<style>
@import "components/Index/css/index.css";
@import "components/Index/css/uikit.min.css";
</style>